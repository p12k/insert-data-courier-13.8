export interface DeliverList{
    
    id:number;
    name:string;
    
    email:string;
  
    contact:string;
}