import { DeliverListComponent } from '../deliverylist/deliverlist.component';
import { AddDeliveryComponent } from '../adddelivery/adddelivery.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { EditComponent } from '../edit/edit.component';
import { AddDeliveryservice } from "src/adddelivery/adddelivery.service";
import { LoginComponent } from '../login/login.component';
import { LogoutComponent } from '../logout/logout.component';
import { AuthGaurdService } from '../guardservice/authguard.service';

const routes: Routes = [
   {path:'home',component:HomeComponent},
  {path:'add',component:AddDeliveryComponent},
  {path:'view',component:DeliverListComponent},
     {path:'edit',component:EditComponent},
{path:'login',component:LoginComponent,},
{path:'Logout',component:LogoutComponent,canActivate:[AuthGaurdService]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
